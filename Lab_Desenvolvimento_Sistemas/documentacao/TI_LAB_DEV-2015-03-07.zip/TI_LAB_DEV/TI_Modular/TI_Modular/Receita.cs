﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Receita : Transacoes
    {
        private List<Receita> listaReceitas;

        public List<Receita> ListaReceitas
        {
            get { return listaReceitas; }
            set { listaReceitas = value; }
        }

        public Receita(string name, double value, DateTime date) {
            this.Nome = name;
            this.Valor = value;
            this.Data = date;
        }

        public Receita() { }

        public List<Receita> bindList() {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(Transacoes.ArqReceitas))
            {
                rd2 = new StreamReader(Transacoes.ArqReceitas, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                int i = 0;

                this.ListaReceitas = new List<Receita> { };
                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    Receita objTransacoes = new Receita(linha[0], double.Parse(linha[1]), Convert.ToDateTime(linha[2])); //CRIO OBJETO APENAS PARA FACILITAR O JOGAR NA LISTA - PODE ALTERAR
                    this.ListaReceitas.Add(objTransacoes);
                    leituraporlinha = rd2.ReadLine();
                    i++;
                } //FIM WHILE

                rd2.Close();
            }

            return this.ListaReceitas;
        }
    }
}
