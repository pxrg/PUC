﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class ControlePagamentos
    {
        protected static string nomeArquivo = "controlePagamentos.txt";
        protected static double taxCondominioFixa = 500;

        private int numeroAp;

        public int NumeroAp
        {
            get { return numeroAp; }
            set { numeroAp = value; }
        }
        
        private double luz;

        public double Luz
        {
            get { return luz; }
            set { luz = value; }
        }
        private DateTime data;

        public DateTime Data
        {
            get { return data; }
            set { data = value; }
        }
        private double rateio;

        public double Rateio
        {
            get { return rateio; }
            set { rateio = value; }
        }
        private double taxCondominio;

        public double TaxCondominio
        {
            get { return taxCondominio; }
            set { taxCondominio = value; }
        }

        private bool devedor;

        public bool Devedor
        {
            get { return devedor; }
            set { devedor = value; }
        }

        private List<ControlePagamentos> controle;

        public List<ControlePagamentos> Controle
        {
            get { return controle; }
            set { controle = value; }
        }

        public ControlePagamentos(int nAp, double luz, DateTime data, double rateio, double taxCond, bool devedor)
        {
            this.NumeroAp = nAp;
            this.Luz = luz;
            this.Data = data;
            this.Rateio = rateio;
            this.TaxCondominio = taxCond;
            this.Devedor = devedor;
        }

        public ControlePagamentos() { }

        public List<ControlePagamentos> bindList()
        {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(ControlePagamentos.nomeArquivo))
            {
                rd2 = new StreamReader(ControlePagamentos.nomeArquivo, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                int i = 0;

                this.Controle = new List<ControlePagamentos>{};
                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    ControlePagamentos controle = new ControlePagamentos(int.Parse(linha[0]), double.Parse(linha[1]), Convert.ToDateTime(linha[2]), double.Parse(linha[3]), double.Parse(linha[4]), bool.Parse(linha[5]));
                    this.Controle.Add(controle);
                    leituraporlinha = rd2.ReadLine();
                    i++;
                } //FIM WHILE

                rd2.Close();
            }

            return this.Controle;
        }

        public void cadastrarPagamento(double luz1, int numeroAp1, Conta conta)
        {
            DateTime data1 = DateTime.Now;
            double rateio = conta.ValorRateio;
            ControlePagamentos objControle = new ControlePagamentos(numeroAp1, luz1, data1, rateio, taxCondominioFixa, false) ;

            FileStream fn;

            if (!File.Exists(ControlePagamentos.nomeArquivo))
            {
                fn = File.Create(ControlePagamentos.nomeArquivo);
            }

            else
            {
                StreamWriter file = new StreamWriter(ControlePagamentos.nomeArquivo, true);
                file.WriteLine("{0} - {1} - {2} - {3} - {4} - {5}", numeroAp1, luz1, data1, rateio, taxCondominioFixa, false);
                file.Close();
            }
        }
    }
}
