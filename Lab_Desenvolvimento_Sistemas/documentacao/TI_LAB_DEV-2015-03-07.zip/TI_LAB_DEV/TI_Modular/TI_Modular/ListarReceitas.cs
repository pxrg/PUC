﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TI_Modular
{
    public partial class ListarReceitas : Form
    {
        public ListarReceitas()
        {
            InitializeComponent();

            Receita receitas = new Receita();
            dataGridView2.DataSource = receitas.bindList();
        }
    }
}
