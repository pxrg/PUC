﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Imovel : ICreate
    {
        protected String fileName = "imoveis.txt";

        private double numeroApartamento;

        public double NumeroApartamento
        {
            get { return numeroApartamento; }
            set { numeroApartamento = value; }
        }

        private List<double> listImoveis;

        public List<double> ListImoveis
        {
            get { return listImoveis; }
            set { listImoveis = value; }
        }

        public Imovel(double nAp)
        {
            this.NumeroApartamento = nAp;
        }

        public Imovel() { }

        public void cadastrar()
        {
            FileStream fn;

            if (!File.Exists(this.fileName))
                fn = File.Create(this.fileName);

            else
            {
                StreamWriter file = new StreamWriter(this.fileName, true);
                file.WriteLine("{0}", this.NumeroApartamento);
                file.Close();
            }
        }

        public List<double> bindList()
        {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(this.fileName))
            {
                rd2 = new StreamReader(this.fileName, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                int i = 0;

                this.ListImoveis = new List<double> { };
                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    Imovel objImovel = new Imovel(double.Parse(linha[0]));
                    this.ListImoveis.Add(objImovel.NumeroApartamento);
                    leituraporlinha = rd2.ReadLine();
                    i++;
                } //FIM WHILE

                rd2.Close();
            }

            return this.ListImoveis;
        }

    }
}
