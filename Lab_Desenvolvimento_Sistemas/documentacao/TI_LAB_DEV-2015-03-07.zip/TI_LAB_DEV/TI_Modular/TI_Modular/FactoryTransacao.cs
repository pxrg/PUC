﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class FactoryTransacao
    {
        /// <summary>
        /// Registra uma nova transação
        /// </summary>
        /// <param name="name">Nome da transação</param>
        /// <param name="value">Valor da transação</param>
        /// <param name="date">Data da transação</param>
        /// <param name="type">1 se for receita, 2 se for despesa</param>
        /// <returns>Objeto do tipo Transacoes</returns>
        public Transacoes registarTransacao(string name, double value, DateTime date, int type) {
            if (type == 1)
            {
                Receita receita = new Receita(name, value, date);
                FileStream fn;

                if (!File.Exists(Transacoes.ArqReceitas))
                {
                    fn = File.Create(Transacoes.ArqReceitas);
                }

                else
                {
                    StreamWriter file = new StreamWriter(Transacoes.ArqReceitas, true);
                    file.WriteLine("{0} - {1} - {2}", name, value, date);
                    file.Close();
                }

                return receita;
            }
            if (type == 2)
            {
                Despesa despesa = new Despesa(name, value, date);

                FileStream fn;

                if (!File.Exists(Transacoes.ArqDespesas))
                {
                    fn = File.Create(Transacoes.ArqDespesas);
                }

                else
                {
                    StreamWriter file = new StreamWriter(Transacoes.ArqDespesas, true);
                    file.WriteLine("{0} - {1} - {2}", name, value, date);
                    file.Close();
                }

                return despesa;
            }
            else return null;
        }
    }
}
