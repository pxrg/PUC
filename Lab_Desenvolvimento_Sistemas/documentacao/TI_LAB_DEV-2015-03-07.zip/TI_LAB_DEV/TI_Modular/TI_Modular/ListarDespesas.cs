﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TI_Modular
{
    public partial class ListarDespesas : Form
    {
        public ListarDespesas()
        {
            InitializeComponent();

            Despesa despesas = new Despesa();
            dataGridView1.DataSource = despesas.bindList();
        }

        private void ListarDespesas_Load(object sender, EventArgs e)
        {

        }

    }
}
