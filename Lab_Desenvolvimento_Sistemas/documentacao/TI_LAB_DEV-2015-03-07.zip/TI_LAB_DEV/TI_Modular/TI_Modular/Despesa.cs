﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Despesa : Transacoes
    {
        private List<Despesa> listaDespesa;

        public List<Despesa> ListaDespesa
        {
            get { return listaDespesa; }
            set { listaDespesa = value; }
        }

        public Despesa(string name, double value, DateTime date) {
            this.Nome = name;
            this.Valor = value;
            this.Data = date;
        }

        public Despesa() { }

        public DateTime getData() {
            return this.Data;
        }

        public List<Despesa> bindList() {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(Transacoes.ArqReceitas))
            {
                rd2 = new StreamReader(Transacoes.ArqDespesas, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                int i = 0;

                this.ListaDespesa = new List<Despesa> { };
                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    Despesa objTransacoes = new Despesa(linha[0], double.Parse(linha[1]), Convert.ToDateTime(linha[2])); //CRIO OBJETO APENAS PARA FACILITAR O JOGAR NA LISTA - PODE ALTERAR
                    this.ListaDespesa.Add(objTransacoes);
                    leituraporlinha = rd2.ReadLine();
                    i++;
                } //FIM WHILE

                rd2.Close();
            }

            return this.ListaDespesa;
        }
    }
}
