﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Transacoes
    {
        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        private double valor;

        public double Valor
        {
            get { return valor; }
            set { valor = value; }
        }

        private DateTime data;

        public DateTime Data
        {
            get { return data; }
            set { data = value; }
        }
        
        // **************************
        public static String ArqReceitas = "receitas.txt";
        public static String ArqDespesas = "despesas.txt";
        public List<Transacoes> despesas = new List<Transacoes>();//LISTA PARA ARMAZENAS AS DESPESAS
        public List<Transacoes> receitas = new List<Transacoes>();//LISTA PARA ARMAZENAS AS RECEITAS

        /** Construtor **/
        public Transacoes(string name, double preco, DateTime Dt)
        {
            this.nome = name;
            this.valor = preco;
            this.data = Dt; //CONVERTE PARA DATETIME
        }

        public Transacoes() { }
     
        public void preencheListaReceitas() //CHAMAR NO BOTAO PARA PREENCHER A LISTA DE RECEITAS
        {
            this.LerArquivo(ArqReceitas, receitas);
        }

        public void preencheListaDespesas() //CHAMAR NO BOTAO PARA PREENCHER A LISTA DE DESPESAS
        {
            this.LerArquivo(ArqDespesas, despesas);
        }

        private void LerArquivo(string str, List<Transacoes> lista) 
        {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(str))
            {
                rd2 = new StreamReader(str, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                //this.ListaAp = new List<List<string>>();
                lista = new List<Transacoes>();
                int i = 0;
                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    Transacoes objTransacoes = new Transacoes(linha[0], double.Parse(linha[1]), Convert.ToDateTime(linha[2])); //CRIO OBJETO APENAS PARA FACILITAR O JOGAR NA LISTA - PODE ALTERAR
                    lista.Add(objTransacoes);
                    leituraporlinha = rd2.ReadLine();
                    i++;
                } //FIM WHILE
            }
        }

        public List<Transacoes> MostraReceitas() //BOTAO MOSTRA RECEITAS
        {
            if (this.receitas == null)
            {
                LerArquivo(Transacoes.ArqReceitas, this.receitas);
                return this.receitas;
            }
            else
                return this.receitas;
        }

        public void imprimePorMes(int mes)
        {
            List<Transacoes> listaPesquisa = new List<Transacoes>();
            for (int i = 0; i < receitas.Count; i++)
            {
                if (receitas[i].Data.Month == mes)
                    listaPesquisa[i] = receitas[i];
            }
        }

    } 
}
