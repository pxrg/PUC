﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Conta
    {

        public Conta()
        { }
        Transacoes objTransacoes = null;
        private double valorRateio;

        public double ValorRateio
        {
            get { return valorRateio; }
            set { valorRateio = value; }
        }
  
        public double Gerarbalancete() 
        {
            double despesas = 0;
            double receitas = 0;            
           
            for (int i = 0; i < objTransacoes.despesas.Count; i++)
               despesas += objTransacoes.despesas[i].Valor; //SOMA O VALOR DO ITEM A UMA VARIAVEL QUE ARMAZENA
            
            for (int i = 0; i < objTransacoes.receitas.Count; i++)
                receitas += objTransacoes.receitas[i].Valor;

            double result = receitas = despesas;
            return result;
        }

        public double calcularRateio() {
            Despesa despesas = new Despesa();
            despesas.bindList();
            DateTime mesAtual = DateTime.Now;
            double nApartamentos = 10;
            double somaDespesa = 0;


            for (int i = 0; i < despesas.ListaDespesa.Count; i++)
            {
                if (despesas.ListaDespesa[i].Data.Month == mesAtual.Month)
                {
                    somaDespesa += despesas.ListaDespesa[i].Valor;
                }
            }

            this.ValorRateio = (somaDespesa / nApartamentos);
            return this.ValorRateio;
        }
    }
}
