﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TI_Modular
{
    public partial class Main : Form
    {
        FactoryTransacao factory = new FactoryTransacao();

        public Main()
        {
            InitializeComponent();
            Imovel imovel = new Imovel();
            imovel.bindList();
            apartamentos_comboBox.DataSource = imovel.ListImoveis;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ContaImovel conta = new ContaImovel();
            conta.lerArquivo();

            Conta controle = new Conta();
            double resultado = 0;
            resultado = controle.calcularRateio();
        }

        private void mostrarFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmitirBalancete balanceteForm = new EmitirBalancete();
            balanceteForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (morador_txtbox.Text != "" && ap_txtbox.Text != "" && sexo_comboBox.Text != "")
            {
                Morador morador = new Morador(morador_txtbox.Text, ap_txtbox.Text, sexo_comboBox.Text);
                morador.cadastrar();

                MessageBox.Show("O(A) usuário(a) " + morador_txtbox.Text + " foi cadastrado(a) com sucesso");
                morador_txtbox.Clear();
                ap_txtbox.Clear();
                sexo_comboBox.SelectedIndex = 0;
            }
            else {
                MessageBox.Show("Preencha todos os campos!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (nApartamento_textBox.Text != "")
            {
                Imovel imovel = new Imovel(double.Parse(nApartamento_textBox.Text));
                imovel.cadastrar();

                MessageBox.Show("Imóvel cadastrado com sucesso");
                nApartamento_textBox.Clear();
            }
            else {
                MessageBox.Show("Preencha todos os campos!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            factory.registarTransacao(nome_despesa_textBox.Text, double.Parse(valor_despesa_textBox.Text), despesa_dateTimePicker.Value, 2);
            
            nome_despesa_textBox.Clear();
            valor_despesa_textBox.Clear();

            MessageBox.Show("Despesa cadastrada com sucesso!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            factory.registarTransacao(receita_textBox.Text, double.Parse(valorReceita_textBox.Text), receita_dateTimePicker.Value, 1);

            receita_textBox.Clear();
            valorReceita_textBox.Clear();

            MessageBox.Show("Receita cadastrada com sucesso!");
        }

        private void listarReceitasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListarReceitas receitasForm = new ListarReceitas();
            receitasForm.Show();
        }

        private void listarDespesasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListarDespesas despesasForm = new ListarDespesas();
            despesasForm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ControlePagamentos controle = new ControlePagamentos();
            Conta conta = new Conta();
            conta.calcularRateio();
            controle.cadastrarPagamento(double.Parse(luz_textBox.Text), int.Parse(apartamentos_comboBox.Text), conta);

            MessageBox.Show("Controle cadastrado com sucesso!");
            luz_textBox.Clear();
        }
    }
}
