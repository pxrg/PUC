﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class ContaImovel
    {
        private String arquivo = @"contasImoveis.txt";

        public String Arquivo
        {
            get { return this.arquivo; }
            set { this.arquivo = value; }
        }
        private int ap;

        public int Ap
        {
            get { return ap; }
            set { ap = value; }
        }

        private double agua;

        public double Agua
        {
            get { return agua; }
            set { agua = value; }
        }

        private double gas;

        public double Gas
        {
            get { return gas; }
            set { gas = value; }
        }

        private double luz;

        public double Luz
        {
            get { return luz; }
            set { luz = value; }
        }

        private int mesLeitura;

        public int MesLeitura
        {
            get { return mesLeitura; }
            set { mesLeitura = value; }
        }

        private int anoLeitura;

        public int AnoLeitura
        {
            get { return anoLeitura; }
            set { anoLeitura = value; }
        }

        private List<String> listaConta;

        public List<String> ListaConta
        {
            get { return listaConta; }
            set { listaConta = value; }
        }

        private List<List<string>> listaAp;

        public List<List<string>> ListaAp
        {
            get { return listaAp; }
            set { listaAp = value; }
        }

        public List<List<string>> lerArquivo()
        {
            StreamReader rd2;
            String[] linha; //recebe do arquivo de leitura
            String leituraporlinha; //AUXILIA O SPLIT

            if (File.Exists(this.Arquivo))
            {
                rd2 = new StreamReader(this.Arquivo, Encoding.Default);
                leituraporlinha = rd2.ReadLine();
                this.ListaAp = new List<List<string>>();

                while (leituraporlinha != null)
                {
                    linha = leituraporlinha.Split('-');
                    this.listaConta = new List<string>();

                    for (int i = 0; i < linha.Length; i++)
                        this.listaConta.Add(linha[i]);
                    
                    leituraporlinha = rd2.ReadLine();
                    this.ListaAp.Add(this.ListaConta);
                } //FIM WHILE
            }

            return this.ListaAp;
        }
    }
}
