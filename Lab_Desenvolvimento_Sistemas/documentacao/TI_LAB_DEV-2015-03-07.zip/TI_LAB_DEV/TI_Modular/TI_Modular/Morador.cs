﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TI_Modular
{
    class Morador : ICreate
    {
        protected String fileName = "moradores.txt";

        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        private string apartamento;

        public string Apartamento
        {
            get { return apartamento; }
            set { apartamento = value; }
        }

        private string sexo;

        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        public Morador(string nome, string ap, string sex) {
            this.Nome = nome;
            this.Apartamento = ap;
            this.Sexo = sex;
        }

        public void cadastrar() {
            FileStream fn;

            if (!File.Exists(this.fileName))
            {
                fn = File.Create(this.fileName);
            }
            else
            {
                StreamWriter file = new StreamWriter(this.fileName, true);
                file.WriteLine("{0} - {1} - {2}", this.Nome, this.Apartamento, this.Sexo);
                file.Close();
            }
        }
    }
}
