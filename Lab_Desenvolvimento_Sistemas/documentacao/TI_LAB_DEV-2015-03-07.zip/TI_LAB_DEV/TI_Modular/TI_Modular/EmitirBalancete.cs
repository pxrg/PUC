﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TI_Modular
{
    public partial class EmitirBalancete : Form
    {
        public EmitirBalancete()
        {
            InitializeComponent();
        }
    }
}
